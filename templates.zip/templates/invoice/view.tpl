<!-- invoice view -->
<!-- Toolbar -->
<div class="container-fluid mb-3">
	{include file="core/tool_bar.tpl"}
</div>

<table width="100%" border="0" cellpadding="20" cellspacing="5">
	<tr>
		<td>
			<table width="700" cellpadding="4" cellspacing="0" border="0" >
				<tr>
					<td class="menuhead2" width="80%">&nbsp;{$translate_invoice_for} {$wo_id}</td>
					<td class="menuhead2" width="20%" align="right" valign="middle">
						<a href="http://www.citecrm.com/docs/#billing" target="new"><img src="images/icons/16x16/help.gif" border="0"></a>
						</td>
					</tr><tr>
					<td class="menutd2" colspan="2">
						<table class="olotable" width="100%" border="0" cellpadding="5" cellspacing="0">
							<tr>
								<td class="menutd">

									{if $error_msg != ""}
										<br>
										{include file="core/error.tpl"}
										<br>
									{/if}
									<!-- Content -->
			
						
								<table width="100%" cellpadding="4" cellspacing="0" border="0" class="olotable">
									<tr class="olotd4">
										<td class="row2"><b>{$translate_invoice_id}</b></td>
										<td class="row2"><b>{$translate_invoice_date}</b></td>
										<td class="row2"><b>{$translate_invoice_due}</b></td>
										<td class="row2"><b>{$translate_invoice_amount}</b></td>	
										<td class="row2"><b>{$translate_invoice_tech}</b></td>
										<td class="row2"><b>{$translate_invoice_work_order}</b></td>
										<td class="row2"><b>{$translate_invoice_date_paid}</b></td>
										<td class="row2"><b>{$translate_invoice_amount_paid}</b></td>
										<td class="row2"><b>{$translate_invoice_balance}</b></td>
									</tr><tr class="olotd4">
										<td>{$invoice.INVOICE_ID}</td>
										<td>{$invoice.INVOICE_DATE|date_format:"%m/%d/%y"}</td>
										<td>{$invoice.INVOICE_DUE|date_format:"%m/%d/%y"}</td>
										<td>${$invoice.INVOICE_AMOUNT|string_format:"%.2f"}</td>
										<td>{$invoice.EMPLOYEE_DISPLAY_NAME}</td>
										<td><a href="?page=workorder:view&wo_id={$invoice.WORKORDER_ID}&page_title={$translate_invoice_wo_id} &{$invoice.WORKORDER_ID}">{$invoice.WORKORDER_ID}</a></td>
										<td>{$invoice.PAID_DATE|date_format:"%m/%d/%y"}</td>
										<td>${$invoice.PAID_AMOUNT|string_format:"%.2f"}</td>
										<td>{if $invoice.BALLANCE > 0}
											<font color="#CC0000">${$invoice.BALLANCE|string_format:"%.2f"}</font>
											{else}
												${$invoice.BALLANCE|string_format:"%.2f"}
											{/if}
										</td>
									</tr><tr>
										<td colspan="3" valign="top">
											<b>{$translate_invoice_bill}</b>
										{foreach item=item from=$customer_details}
											<table width="100%" cellpadding="0" cellspacing="0">
												<tr>
													<td valign="top">
														<a href="?page=customer:customer_details&customer_id={$item.CUSTOMER_ID}&page_title={$item.CUSTOMER_DISPLAY_NAME}">{$item.CUSTOMER_DISPLAY_NAME}</a><br>
														{$item.CUSTOMER_PHONE}<br>
														{$item.CUSTOMER_ADDRESS}<br>
														{$item.CUSTOMER_CITY}, {$item.CUSTOMER_STATE} {$item.CUSTOMER_ZIP}<br>
														{$item.CUSTOMER_EMAIL}
													</td>
												</tr>
											</table>
											{/foreach}		
										</td>

										<td colspan="6" valign="top"  align="right">
											<table cellpadding="0" cellspacing="0">
												<tr>
													<td valign="top">
													<b>{$translate_invoice_pay}</b>
														<table cellpadding="0" cellspacing="0" width="100%">
															<tr>
																<td valign="top">
																	{section name=x loop=$company}
																		{$company[x].COMPANY_NAME} <br>
																		{$company[x].COMPANY_ADDRESS}<br>
																		{$company[x].COMPANY_CITY}, {$company[x].COMPANY_STATE} {$company[x].COMPANY_ZIP}<br>
																		{$company[x].COMPNAY_PHONE}<br>
																	{/section}
																</td>
															</tr>
														</table>
													</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br>

								{if $invoice.INVOICE_AMOUNT > 0 }
									<p> <a href="?page=invoice:print&wo_id={$invoice.WORKORDER_ID}&customer_id={$invoice.CUSTOMER_ID}&invoice_id={$invoice.INVOICE_ID}&escape=1" target="new">{$translate_invoice_print}</a>
									</p>
								{/if}
									
								<br>
								<table width="100%" cellpadding="4" cellspacing="0" border="0" >
									<tr>
										<td class="menuhead2">&nbsp;{$translate_invoice_labor}</td>
									</tr><tr>
										<td class="menutd2">
										{if $labor != '0'}	
									
											<table width="100%" cellpadding="4" cellspacing="0" border="0" class="olotable">
												<tr  class="olotd4">
													<td class="row2"><b>{$translate_invoice_no}</b></td>
													<td class="row2" width="12"><b>{$translate_invoice_hours}</b></td>
													<td class="row2"><b>{$translate_invoice_description}</b></td>
													<td class="row2"><b>{$translate_invoice_rate}</b></td>
													<td class="row2"><b>{$translate_invoice_total}</b></td>
												</tr>
												{section name=q loop=$labor}
											   		<tr class="olotd4">
														<td>{$smarty.section.q.index+1}</td>
														<td>{$labor[q].INVOICE_LABOR_UNIT}</td>
														<td>{$labor[q].INVOICE_LABOR_DESCRIPTION}</td>
														<td>${$labor[q].INVOICE_LABOR_RATE|string_format:"%.2f"}</td>
														<td>${$labor[q].INVOICE_LABOR_SUBTOTAL|string_format:"%.2f"}</td>
													</tr>
												{/section}
											</table>
										{/if}
										</td>
									</tr>
								</table>
								
							 	<br>
								<table width="100%" cellpadding="4" cellspacing="0" border="0" >
									<tr>
										<td class="menuhead2">&nbsp;{$translate_invoice_parts}</td>
									</tr><tr>
										<td class="menutd2">
										{if $parts != '0'}
											<table width="100%" cellpadding="4" cellspacing="0" border="0" class="olotable">
												<tr class="olotd4">
													<td class="row2"><b>{$translate_invoice_no}</b></td>
													<td class="row2"><b>{$translate_invoice_count}</b></td>
													<td class="row2"><b>{$translate_invoice_description}</b></td>
													<td class="row2"><b>{$translate_invoice_man}</b></td>
													<td class="row2"><b>{$translate_invoice_price}</b></td>	
													<td class="row2"><b>{$translate_invoice_total}</b></td>
												</tr>
												{section name=w loop=$parts}
												<tr class="olotd4">
													<td>{$smarty.section.w.index+1}</td>
													<td>{$parts[w].INVOICE_PARTS_COUNT}</td>
													<td>{$parts[w].INVOICE_PARTS_DESCRIPTION}</td>
													<td>{$parts[w].INVOICE_PARTS_MANUF}</td>
													<td>${$parts[w].INVOICE_PARTS_AMOUNT|string_format:"%.2f"}</td>
													<td>${$parts[w].INVOICE_PARTS_SUBTOTA|string_format:"%.2f"}</td>
												</tr>	
												{/section}
											</table>
										{/if}
										</td>		
									</tr>
								</table>
								<br>
								<table width="100%" cellpadding="4" cellspacing="0" border="0" >
									<tr>
										<td class="menuhead2">&nbsp;{$translate_invoice_total}</td>
									</tr><tr>
										<td class="menutd2">
											<table width="100%" cellpadding="4" cellspacing="0" border="0" class="olotable">
												<tr>
													<td class="olotd4" width="80%" align="right"><b>{$translate_invoice_sub_total}</b></td>
													<td class="olotd4" width="20%" align="right">${$invoice.SUB_TOTAL}</td>
												</tr><tr>
													<td class="olotd4" width="80%" align="right"><b>{$translate_invoice_shipping}</b></td>
													<td class="olotd4" width="20%" align="right">${$invoice.SHIPPING}</td>
												</tr><tr>
													<td class="olotd4" width="80%" align="right"><b>{$translate_invoice_tax}</b></td>
													<td class="olotd4" width="20%" align="right">${$invoice.TAX}</td>
												</tr><tr>
													<td class="olotd4" width="80%" align="right"><b>{$translate_invoice_discount}</b></td>
													<td class="olotd4" width="20%" align="right">- ${$invoice.DISCOUNT|default:"0.00"}</td>
												</tr><tr>
													<td class="olotd4" width="80%" align="right"><b>{$translate_invoice_total}</b></td>
													<td class="olotd4" width="20%" align="right">${$invoice.INVOICE_AMOUNT}</td>
												</tr>
											</table>
										</td>
									</tr>
								</table>
								<br>
								<!-- Trans action log -->
								<table width="100%" cellpadding="4" cellspacing="0" border="0" >
									<tr>
										<td class="menuhead2">&nbsp;{$translate_invoice_trans_log}</td>
									</tr><tr>
										<td class="menutd2">
											<table width="100%" cellpadding="4" cellspacing="0" border="0" class="olotable">
												<tr class="olotd4">
													<td class="row2"><b>{$translate_invoice_trans_id}</b></td>
													<td class="row2"><b>{$translate_invoice_date}</b></td>
													<td class="row2"><b>{$translate_invoice_amount}</b></td>
													<td class="row2"><b>{$translate_invoice_type}</b></td>
												</tr>
												{section name=r loop=$trans}
												<tr class="olotd4">
													<td>{$trans[r].TRANSACTION_ID}</td>
													<td>{$trans[r].DATE|date_format:"%m/%d/%y %r"}</td>
													<td><b>$</b>{$trans[r].AMOUNT}</td>
													<td>
													{if $trans[r].TYPE == 1}
														{$translate_invoice_cc}
													{elseif $trans[r].TYPE == 2}
														{$translate_invoice_check}
													{elseif $trans[r].TYPE == 3}
														{$translate_invoice_cash}
													{elseif $trans[r].TYPE == 4}
														{$translate_invoice_gift}
													{elseif $trans[r].TYPE == 5}
														{$translate_invoice_paypal}
													{/if}
													</td>
												</tr><tr class="olotd4">
													<td><b>{$translate_invoice_memo}</b></td>
													<td colspan="3">{$trans[r].MEMO}</td>
												</tr>
												{/section}
											</table>
										</td>
									</tr>
								</table>
													
								</td>
							</tr>
						</table>
								
					</td>
				</tr>
			</table>

		</td>
	</tr>
</table>
			
