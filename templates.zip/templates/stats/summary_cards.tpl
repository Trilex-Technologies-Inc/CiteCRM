<div class="row g-3">

	<!-- Work Orders -->
	<div class="col-md-6 col-lg-3">
		<div class="card h-100 border-0 bg-light">
			<div class="card-body">
				<h6 class="card-title fw-bold">Work Orders</h6>
				<div class="d-flex justify-content-between">
					<span>Open Work Orders:</span>
					<span>{$month_open|default:0}</span>
				</div>
				<div class="d-flex justify-content-between">
					<span>Closed Work Orders:</span>
					<span>{$month_closed|default:0}</span>
				</div>
			</div>
		</div>
	</div>

	<!-- Customers -->
	<div class="col-md-6 col-lg-3">
		<div class="card h-100 border-0 bg-light">
			<div class="card-body">
				<h6 class="card-title fw-bold">Customers</h6>
				<div class="d-flex justify-content-between">
					<span>New Customers:</span>
					<span>{$new_customers|default:0}</span>
				</div>
				<div class="d-flex justify-content-between">
					<span>Total Customers:</span>
					<span>{$total_customers|default:0}</span>
				</div>
			</div>
		</div>
	</div>

	<!-- Invoices -->
	<div class="col-md-6 col-lg-3">
		<div class="card h-100 border-0 bg-light">
			<div class="card-body">
				<h6 class="card-title fw-bold">Invoices</h6>
				<div class="d-flex justify-content-between">
					<span>Open Invoices:</span>
					<span>{$open_invoices|default:0}</span>
				</div>
				<div class="d-flex justify-content-between">
					<span>Closed Invoices:</span>
					<span>{$closed_invoices|default:0}</span>
				</div>
			</div>
		</div>
	</div>

	<!-- Revenue -->
	<div class="col-md-6 col-lg-3">
		<div class="card h-100 border-0 bg-light">
			<div class="card-body">
				<h6 class="card-title fw-bold">Revenue</h6>
				<div class="d-flex justify-content-between">
					<span>Total Revenue:</span>
					<span>$ {$total_revenue|default:"0.00"}</span>
				</div>
				<div class="d-flex justify-content-between">
					<span>Losses:</span>
					<span>$ {$total_losses|default:"0.00"}</span>
				</div>
			</div>
		</div>
	</div>

</div>

